﻿using UnityEngine;
using System.Collections;

public class EnvironmentModules : MonoBehaviour
{

	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		
	}

	void OnTriggerExit (Collider Box)
	{
		if (Box.transform.tag == "MainCamera")
		{
			Destroy (gameObject);
		}
	}
}
