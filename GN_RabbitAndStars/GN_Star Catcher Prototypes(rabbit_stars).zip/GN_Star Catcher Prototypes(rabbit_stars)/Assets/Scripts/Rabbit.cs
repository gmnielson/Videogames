﻿using UnityEngine;
using System.Collections;

public class Rabbit : MonoBehaviour {

	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		Transform tran = transform;

		if (Input.GetKeyDown (KeyCode.LeftArrow))
		{
			tran.rotation = Quaternion.Euler (0, 0, 0);
		}

		if (Input.GetKeyDown (KeyCode.RightArrow))
		{
			tran.rotation = Quaternion.Euler (0, 180, 0);
		}
	}
}
