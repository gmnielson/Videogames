﻿using UnityEngine;
using System.Collections;

public class Star : MonoBehaviour
{
	public float starSpeed;
	private Vector3 direction;
	public float lifetime = 6;
	private float xRotateSpeed = 0;
	private float zRotateSpeed = 0;

	// Use this for initialization
	void Start ()
	{
		direction = new Vector3 (Random.Range (-0.25f, 0.25f), Random.Range (-2.0f, 0.0f), 0.0f).normalized;

		xRotateSpeed = Random.Range (1, 20);
		zRotateSpeed = Random.Range (5, 90);

		Destroy (gameObject, lifetime);
		/*Transform rota = transform;
		int randRota = Random.Range (175, 240);
		rota.rotation = Quaternion.Euler (0, 0, randRota);

		sBody = GetComponent <Rigidbody> ();*/
	}
	
	// Update is called once per frame
	void Update ()
	{
		transform.Rotate (Vector3.right, xRotateSpeed * Time.deltaTime);
		transform.Rotate (Vector3.forward, zRotateSpeed * Time.deltaTime);

		transform.position += direction * starSpeed * Time.deltaTime;
	}
}
