﻿using UnityEngine;
using System.Collections;

public class FloorController : MonoBehaviour {

	private GameObject cam;
	public float speed;
	private float dist = 15.4f;
	private float distance = 0;
	public GameObject[] modules;
	private int whileLoop = 3;

	void Awake ()
	{
		while (whileLoop > 0)
		{
			Invoke ("SpawnModule", 0);
			whileLoop--;
		}
	}

	void Start ()
	{
		cam = GameObject.FindWithTag("MainCamera");
	}

	// Update is called once per frame
	void Update ()
	{
		transform.Translate (-Vector3.right * speed * Time.deltaTime);

		if (cam.transform.position.x > dist)
		{
			Invoke ("SpawnModule", 0);
			dist = AddByDist (dist);
		}
	}

	float AddByDist (float number)
	{
		float ret;
		ret = number + 15.4f;
		return ret;
	}

	void SpawnModule ()
	{
		int objectIndex = Random.Range (0, modules.Length);

		Instantiate (modules [objectIndex], new Vector3 (transform.position.x + distance,
			 transform.position.y, transform.position.z), Quaternion.identity);
		
		distance = AddByDistance (distance);
	}

	float AddByDistance (float number)
	{
		float ret;
		ret = number + 15.4f;
		return ret;
	}
}
