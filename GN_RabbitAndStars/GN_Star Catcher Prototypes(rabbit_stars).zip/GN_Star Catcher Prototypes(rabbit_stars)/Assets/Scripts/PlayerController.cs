﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour
{

	public float moveSpeed = 3f;
	private Rigidbody cBody;

	public float jumpForce = 4f;
	private bool canDoubleJump;

	public float camMovSpeed;
	public float addNumber;
	public float xKiller;
	public float xMin;
	public float xMax;
	public float yMin;
	public float yMax;

	bool grounded = false;

	// Use this for initialization
	void Start ()
	{
		cBody = GetComponent<Rigidbody> ();
	}

	// Update is called once per frame
	void Update ()
	{

		if(Input.GetKey(KeyCode.RightArrow))
			transform.Translate(Vector3.right * moveSpeed * Time.deltaTime);

		if (Input.GetKey (KeyCode.LeftArrow))
			transform.Translate (-Vector3.right * moveSpeed * Time.deltaTime);

		if (Input.GetKeyDown (KeyCode.Space))
		{
			if (grounded == false)
			{
				cBody.velocity += Vector3.up * jumpForce;
				canDoubleJump = true;
				grounded = true;
			}
			else
			{
				if (canDoubleJump == true)
				{
					canDoubleJump = false;
					cBody.velocity += Vector3.up * jumpForce;
					grounded = true;
				}
			}

		}
	}

	void FixedUpdate ()
	{
		float clampMove = camMovSpeed * Time.deltaTime;

		cBody.position = new Vector3 (
			Mathf.Clamp (cBody.position.x, xMin + clampMove, xMax + clampMove),
			Mathf.Clamp (cBody.position.y, yMin, yMax),
			0.0f
		);
			
		float furLeft = xKiller + clampMove;

		if (cBody.position.x < furLeft || cBody.position.y == yMin)
		{
			Application.LoadLevel (Application.loadedLevel);
			//SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
		}

		camMovSpeed = Addition (camMovSpeed);
	}

	float Addition (float number)
	{
		float ret;
		ret = number + addNumber;
		return ret;
	}

	void OnCollisionEnter (Collision col)
	{
		if (col.gameObject.tag == "Floor")
		{
			grounded = false;
		}
	}
}