﻿using UnityEngine;
using System.Collections;

public class StarController : MonoBehaviour
{

	public GameObject[] star;
	public float spawnRepeat;
	private GameObject cam;
	public float xMin;
	public float xMax;

	// Use this for initialization
	void Start ()
	{
		InvokeRepeating ("StarSpawn", 0, spawnRepeat);
	}
	
	// Update is called once per frame
	void Update ()
	{
	
	}

	void StarSpawn ()
	{
		int spawnStar = Random.Range (0, star.Length);

		cam = GameObject.Find ("Main Camera");
		float spawnMin = cam.transform.position.x + xMin;
		float spawnMax = cam.transform.position.x + xMax;
		float x = Random.Range (spawnMin, spawnMax);

		Instantiate (star [spawnStar], new Vector3 (x, 3.57f, 0.0f), Quaternion.identity);
	}
}
